package com.example.myksvit;

public class UserProfile {

    public String userphoneno;
    public String userEmail;
    public String userName;
    public String usermoney;

    public UserProfile(){
    }

    public UserProfile(String userphoneno, String userEmail, String userName, String usermoney) {
        this.userphoneno = userphoneno;
        this.userEmail = userEmail;
        this.userName = userName;
        this.usermoney= usermoney;
    }

    public String getUserphoneno() {
        return userphoneno;
    }

    public void setUserphoneno(String userphoneno) {
        this.userphoneno = userphoneno;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) { this.userName = userName; }

    public String getUsermoney() { return usermoney; }

    public void setUsermoney(String usermoney) { this.usermoney = usermoney; }

}
