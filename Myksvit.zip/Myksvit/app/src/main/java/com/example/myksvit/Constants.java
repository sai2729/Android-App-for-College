package com.example.myksvit;

public class Constants {

    public static final String STORAGE_PATH_UPLOADS = "uploads/";
    public static final String DATABASE_PATH_UPLOADS = "uploads";
    public static final String DATABASE_PATH_UPLOADS11= "uploads11";
    public static final String DATABASE_PATH_UPLOADS12= "uploads12";
    public static final String DATABASE_PATH_UPLOADS21= "uploads21";
    public static final String DATABASE_PATH_UPLOADS22= "uploads22";
    public static final String DATABASE_PATH_UPLOADS31= "uploads31";
    public static final String DATABASE_PATH_UPLOADS32= "uploads32";
    public static final String DATABASE_PATH_UPLOADS41= "uploads41";
    public static final String DATABASE_PATH_UPLOADS42= "uploads42";
    public static final String STORAGE_PATH_MATERIALS = "materials/";
    public static final String DATABASE_PATH_MATERIALS = "materials";

}
